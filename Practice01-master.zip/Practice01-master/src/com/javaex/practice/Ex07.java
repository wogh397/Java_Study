package com.javaex.practice;

public class Ex07 {

	public static void main(String[] args) {

		/*
		다음 코드에서 변수로 사용할 수 없는 경우 이유를 작성하세요.
		
		int true;						//예약어
		int #_of_workers;				//#사용
		int countOfLettersInString;
		int	1stLevel1;					//숫자 변수의 앞에사용
		int	person#;					//#사용
		int _person;
		*/
		
		
	}

}
