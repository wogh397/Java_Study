package com.javaex.practice;

public class Ex17 {

	public static void main(String[] agrgs) {
		
		/*
		//문제
		int x, y
		
		x = 10
		y = 20
		
		sum = x + y
		
		System.out.println("합은 ' + sum);
		*/
		
		
		//풀이
		int x, y ;
		
		x = 10;
		y = 20;
		
		int sum = x + y;
		
		System.out.println("합은 " + sum);
		
	}

}
