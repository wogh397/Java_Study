package com.javaex.practice;

public class Ex10 {

	public static void main(String[] args) {

		/*
		형변환 우선순위를 그린 표이다. 아래의 빈칸을 채우세요
		
		(1)byte
		(2)short
		(3)2byte
		(4)4byte
		(5)long
		(6)float
		(7)double
		*/
		
		
	}

}
