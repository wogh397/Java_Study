package com.javaex.practice;

public class Ex24 {

	public static void main(String[] agrgs) {
		/*
		//문제
		double f=80.0;
		System.out.println(5/9*(f-32.0));
		*/
		
		//풀이
		double f=80.0;
		System.out.println((double)5/(double)9 * (f-32.0));
		// 5/9가 실수형이 나오도록 해야된다
	}

}
