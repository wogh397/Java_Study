package com.javaex.practice;

public class Ex18 {

	public static void main(String[] agrgs) {
		
		/*
		//문제
		int x;
		System.out.println(x);
		*/
		
		//풀이
		int x = 10;    //초기화(초기값)가 되지 않았다
		System.out.println(x);
		
	}

}
