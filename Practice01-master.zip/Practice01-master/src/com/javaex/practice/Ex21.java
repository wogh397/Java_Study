package com.javaex.practice;

public class Ex21 {

	public static void main(String[] agrgs) {
		
		int i = 10;
		int n = ++i %2;
		// i를1증가(10->11)  11%2=>1  1을n에대입  
		
		System.out.println(i);
		System.out.println(n);
		
	}
	

}
