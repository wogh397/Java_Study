package com.javaex.practice;

public class Ex20 {

	public static void main(String[] agrgs) {
		
		int i = 10;
		int n = i++ %2;
		// 10%2=>0  0을n에대입  i를1증가(10->11)
		
		System.out.println(i);
		System.out.println(n);
		
	}

}
