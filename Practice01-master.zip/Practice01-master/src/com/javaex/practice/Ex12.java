package com.javaex.practice;

public class Ex12 {

	public static void main(String[] args) {

		/*
		//문제
		int x, y = 0;			//x와 y를 모두 0으로 초기화
		char grade = "A";		//문자 A를 grage에 대입
		int salary = 2,000,000;	//salary에 2,000,000을 대입
		byte n = 1000;			//n에 1000을 대입
		*/
		
		//풀이
		int x=0, y=0;
		char grade = 'A';
		String grade2 ="A";
		int salary = 2000000;
		String salary2 = "2,000,000";
		int n = 1000; 					//-128~127
	}
		

}
