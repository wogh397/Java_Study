package com.javaex.practice;

public class Ex23 {

	public static void main(String[] args) {
		
		double speed;
		double time;
		double distance;
		
		speed = 90.0;
		time = 60.0;
		distance = speed * time;
		
		System.out.println(distance);
		
	}

}
