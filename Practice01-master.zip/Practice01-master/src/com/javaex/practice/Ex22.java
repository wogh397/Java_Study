package com.javaex.practice;

public class Ex22 {

	public static void main(String[] args) {
		
		System.out.println( 17 < 17 );   // false
		System.out.println( 17 <= 17 );  // true
		System.out.println( 5 >= 17 );   // false
		System.out.println( 5 >= 5 );    // true
		System.out.println( 5 == 17 );   // false 
		System.out.println( 5 != 17 );   // true
		System.out.println( !(5==17) );  // true
	
	}

}
