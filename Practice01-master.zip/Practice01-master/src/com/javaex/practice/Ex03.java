package com.javaex.practice;

public class Ex03 {

	public static void main(String[] args) {

		/*
		JVM에 대한 설명으로 틀린 것을 찾아 수정해보세요
		(1)	JVM은 java.exe 명령어에 의해 구동된다
		(2)	JVM은 바이트코드(~.class)를 기계어로 변환시키고 구동시키다.
		(3)	운영체제별로 동일한 JVM이 사용된다.
		(4)	바이트코드(~.class)는 운영체제에 독립적이만, JVM은 운영체제에 종속적이다.

		3번 
		JVM은 운영체제에 종속적으로 
		운영체제에 맞는 JVM를 포함하고 있는 JRE를 다운받아 사용해야 한다

		*/
		
		
	}

}
