package com.javaex.practice;

public class Ex01 {

	public static void main(String[] args) {

		/*
		다음중 기본 자료형중 정수형자료형이 아닌 것은? 
		
		(1)	int
		(2)	float   
		(3)	byte
		(4)	long

		2번
		실수형 자료형으로 4byte 이며 double도 8byte의실수형 자료형이다
		*/
		
	}

}
