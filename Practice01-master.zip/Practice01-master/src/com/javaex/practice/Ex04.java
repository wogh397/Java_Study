package com.javaex.practice;

public class Ex04 {

	public static void main(String[] args) {

		/*
		java 프로그램 개발과정을 순서대로 나열해 보세요
		
		(1)	Javac.exe로 바이트코드(~.class)을 생성한다
		(2)	Java.exe로 JVM을 구동시킨다..
		(3)	자바소스파일(~.java)을 작성한다
		(4)	JVM은 main() 메소드를 찾아 실행시킨다.

		3 --> 1 --> 2 --> 4
		*/
		
		
	}

}
