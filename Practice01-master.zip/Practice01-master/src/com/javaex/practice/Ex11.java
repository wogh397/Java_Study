package com.javaex.practice;

public class Ex11 {

	public static void main(String[] args) {
		
		int iVar = 10;
		
		long lVar = 1000000000000L;
		
		//char cVar ='ab';    //char형은 1글자만 사용할 수 있다
		char cVar = 'a';
		
		double dVar = 10;
		
		//float fVar = 12.4;    // float형은 항상 맨뒤에 F를 붙여 사용한다 
		float fVar = 12.4F;
		
		//String str = 'ab';    // String은 ""를 사용한다
		String str = "ab";
	}


}
