package com.javaex.practice;

public class Ex09 {

	public static void main(String[] args) {

		/*
		아래와 예제와 같이 작성해 보세요
		
		예제) int 4byte 정수형
		short	(2byte)	(정수형)
		double	(8byte)	(실수형)
		float	(4byte)	(실수형)
		byte	(1byte)	(정수형)
		char	(2byte)	(문자형)
		boolean	(1byte)	(논리형)
		long	(8byte)	(정수형)
		*/
		
		
		
	}

}
