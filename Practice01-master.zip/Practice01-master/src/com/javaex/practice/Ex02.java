package com.javaex.practice;

public class Ex02 {

	public static void main(String[] args) {

		/*
		(1)	자바 프로그램을 개발하려면 JDK가 반드시 필요하다.
		(2)	자바 프로그램을 실행만 하려고 할 때는 JRE가 있으면 된다
		(3)	JDK는 개발도구 와 JRE로 구성되어 있다
		(4)	JDK에는 javac.exe가 포함되어 있지 않다.
		
		4번 
		jdk는 개발도구+jre로 구성되어 있으면 javac.exe가 포함되어 있다 
		javac.exe를 통해 컴파일을 하며
		컴파일 후에는 바이트코드(~.class)파일이 생성된다
		*/
		
		
	}

}
