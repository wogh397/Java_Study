package com.javaex.practice;

public class Hello { // 클래스명은 대문자로 시작해야 한다
	                 // 문제에는 소문자로 시작하고 있음 (hello)

	public static void main(String[] args) {

		System.out.println("Hello World");

	}

}
