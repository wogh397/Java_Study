/**
 * 
 */
/**
 * 
 */
module Practice01 {
}