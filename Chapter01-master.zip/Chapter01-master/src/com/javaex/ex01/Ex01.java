package com.javaex.ex01;

//클래스
public class Ex01 {
	
	//메소드
	public static void main(String[] args) {
		
		//변수선언 + 초기화
		int myAge = 25;
		
		/*
		//변수선언
		int myAge;
		
		//초기화
		myAge = 25;
		*/
		
		//메소드사용(출력)
		System.out.println(myAge);
		
		//대입  25-->100
		myAge = 100;
		
		//메소드사용(출력)
		System.out.println(myAge);
		
		
	}

}

