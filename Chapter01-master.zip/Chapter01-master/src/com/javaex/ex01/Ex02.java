package com.javaex.ex01;

//클래스
public class Ex02 {

	//메소드
	public static void main(String[] args) {

		
		//변수선언
		int var01;
		int var02;
		int var03;
		//int var01, var02, var03;
		
		//초기화
		var01 = 120;
		var02 = 200;
		var03 = 300;
		
		
		/*
		//변수선언+초기화
		int var01 = 100;
		int var02 = 200;
		int var03 = 300;
		//int var01 = 100, var02 = 200, var03 = 300;
		*/
		
		System.out.println(var01);
		System.out.println(var02);
		System.out.println(var03);
	}
	
}
