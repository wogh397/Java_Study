package com.javaex.ex01;

//클래스
public class Ex05 {

	//메소드
	public static void main(String[] args) {
		
		boolean b01 = true;
		boolean b02 = false;
		
		System.out.println(b01);
		System.out.println(b02);
	
		int a = 5;
		int b = 3;
		
		boolean result = a>b;
		System.out.println(result);
		
	}
	
	
}
