package com.javaex.ex01;

//클래스
public class Ex03 {
	
	//메소드
	public static void main(String[] args) {
	
		/////////////////////////////
		//byte
		//////////////////////////////
		
		//변수선언
		byte no;
		
		//대입(초기화)
		no = 0;
		
		//출력
		System.out.println(no);
		
		/////////////////////////////
		//long
		//////////////////////////////
		//long형은 int범위까지는 그냥쓰면된다
		//int범위를 벗어나면 L 을 붙여야한다
		//그래서 나는 계속 붙여쓴다
		long no2 = 2147483648L;
		
	
		
	}
	
}
