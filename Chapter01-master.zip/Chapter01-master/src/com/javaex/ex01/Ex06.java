package com.javaex.ex01;

//클래스
public class Ex06 {

	//메소드
	public static void main(String[] args) {
		
		char ch01 = 'A';
		char ch02 = '안';
		
		System.out.println(ch01);
		System.out.println(ch02);
		
		
		char ch03 = '6';
		char ch04 = 6;  //문자코드번호 6
		
		System.out.println(ch03);
		System.out.println(ch04);
		
		
		String str = "안녕하세요";
		System.out.println(str);
	}
}
