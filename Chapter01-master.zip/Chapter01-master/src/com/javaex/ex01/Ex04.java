package com.javaex.ex01;

//클래스
public class Ex04 {

	//메소드
	public static void main(String[] args) {
		///////////////////////////////
		//float
		///////////////////////////////
		
		double var01 = 3.14;
		float var02 = 3.14F;  //float형은 꼭 F를 붙여서 써야한다
		
		System.out.println(var01);
		System.out.println(var02);
		
		
		
		double var03 = 0.1234567890123456789;
		float var04 = 0.1234567890123456789F;
		System.out.println(var03);
		System.out.println(var04);
		
		
		double var05 = 1234567890.123456789;
		float var06 = 1234567890.123456789F;
		System.out.println(var05);
		System.out.println(var06);
		
		
	}
}
