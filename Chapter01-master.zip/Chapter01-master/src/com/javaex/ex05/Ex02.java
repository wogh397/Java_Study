package com.javaex.ex05;

public class Ex02 {

	public static void main(String[] args) {

		int no1; 
		int no2;
		int no3;
		int no4;
		int no5;
		int no6;
		
		//변수명은 일렬번호를 붙일수 없다  ==> 배열
		
		for(int i=1; i<=6; i++) {
			//System.out.println(   (int)(Math.random()*45)+1    );
			//no+i= (int)(Math.random()*45)+1; 
		}
		
		for(int i=1; i<=6; i++) {
			System.out.println(  "no" + i   );
		}
		
	}

}
