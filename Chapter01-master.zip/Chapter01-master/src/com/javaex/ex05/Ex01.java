package com.javaex.ex05;

public class Ex01 {

	public static void main(String[] args) {
		/*
		System.out.println(   (int)(Math.random()*45)+1    );
		System.out.println(   (int)(Math.random()*45)+1    );
		System.out.println(   (int)(Math.random()*45)+1    );
		System.out.println(   (int)(Math.random()*45)+1    );
		System.out.println(   (int)(Math.random()*45)+1    );
		System.out.println(   (int)(Math.random()*45)+1    );
		*/
		
		int no1 = (int)(Math.random()*45)+1 ;
		int no2 = (int)(Math.random()*45)+1 ;
		int no3 = (int)(Math.random()*45)+1 ;
		int no4 = (int)(Math.random()*45)+1 ;
		int no5 = (int)(Math.random()*45)+1 ;
		int no6 = (int)(Math.random()*45)+1 ;
		
		System.out.println(no1);
		System.out.println(no2);		
		System.out.println(no3);
		System.out.println(no4);
		System.out.println(no5);
		System.out.println(no6);
		
		System.out.println("---------------------");
		
		
		System.out.println(no1);
		System.out.println(no2);		
		System.out.println(no3);
		System.out.println(no4);
		System.out.println(no5);
		System.out.println(no6);
	}

}
