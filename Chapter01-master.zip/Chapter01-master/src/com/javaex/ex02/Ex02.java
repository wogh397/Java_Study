package com.javaex.ex02;

import java.util.Scanner;

//클래스
public class Ex02 {

	//메소드
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
		System.out.println(num);
	
		
		sc.close();
	}

}
