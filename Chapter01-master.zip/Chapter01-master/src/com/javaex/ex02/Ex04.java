package com.javaex.ex02;

public class Ex04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
