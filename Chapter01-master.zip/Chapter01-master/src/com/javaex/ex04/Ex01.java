package com.javaex.ex04;

public class Ex01 {

	public static void main(String[] args) {
		
		//초기화  증감식  조건식
		
		int i = 0;
		
		while( i<5 ) {
			
			System.out.println("I like java" + i);
			
			i++;
			
		}
		

	}

}
