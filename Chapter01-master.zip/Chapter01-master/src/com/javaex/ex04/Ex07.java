package com.javaex.ex04;

public class Ex07 {

	public static void main(String[] args) {
		
		//y축  출력X
		for(int y=1; y<=6; y++) {
			
			//x축 가로출력
			for(int x=1; x<=6; x++) {
				System.out.print("*");
			}
			
			//줄바꿈
			System.out.println("");
			
			
		}
	
		
	}

}
