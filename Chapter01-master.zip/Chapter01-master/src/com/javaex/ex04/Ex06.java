package com.javaex.ex04;

public class Ex06 {

	public static void main(String[] args) {

		// dan (2-->9)
		for(int dan=2; dan<=9; dan++) {
			//System.out.println("단=" + dan);
			
			// i (1-->9)
			for(int i=1; i<=9; i++) {
				//System.out.println("뒤에=" + i);
				
				System.out.println(dan + "*" + i + "=" + dan*i);
				
			}
		}
		
	}

}
