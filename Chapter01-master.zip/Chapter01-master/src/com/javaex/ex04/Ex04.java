package com.javaex.ex04;

public class Ex04 {

	public static void main(String[] args) {
		

		//식을 만든다(공통부분)
		// 초기값 조건식 증감식
		
		for(int i=0; i<5; i++ ) {
		
			System.out.println("I Like Java"+ i);
		
		}
		
		
		
		
		
	}

}
