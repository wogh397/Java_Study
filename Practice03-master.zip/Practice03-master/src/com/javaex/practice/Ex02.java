package com.javaex.practice;

public class Ex02 {

	public static void main(String[] args) {

		int x, y;
		for(x=0; x<4; x++) {
			for(y=0; y<2; y++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}

}


