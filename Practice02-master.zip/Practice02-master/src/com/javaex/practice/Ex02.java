package com.javaex.practice;

public class Ex02 {

	public static void main(String[] args) {

		/*
		다음중 switch 문에서 조건식에 넣을 수 있는 데이터 타입은?
			(1)	boolean    	X
			(2)	char       	O
			(3)	byte   		O
			(4)	short		O
			(5)	int			O
			(6)	long 		X
			(7)	float		X
			(8)	double		X
			(9)	String		O
		*/
		
	}

}
