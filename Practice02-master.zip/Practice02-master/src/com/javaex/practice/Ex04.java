package com.javaex.practice;

public class Ex04 {

	public static void main(String[] args) {
		int x = 0;

		//if ( x=0 ) {
		if ( x==0 ) {	// x가 0과 같으면 
			System.out.println("x는 0이다.");
		}

	}

}
