package com.javaex.practice;

public class Ex01 {

	public static void main(String[] args) {
		
		/*
		다음중 에러가 발생하는 문장은
		(1)	if( i=0 ) {….}
			--> if( i==0 ) {...}
		
		(2)	if( j<10 ) {…}
			--> 정상
			
		(3)	switch( 'A' ){….}
			--> 정상
		
		(4)	switch( 100 ){…}
			--> 정상
		
		(5)	switch( "A" ){…}
			--> 정상
		
		(6)	if( name == "홍길동" )
			--> name.equals("홍길동");
		*/
				
		
	}

}
