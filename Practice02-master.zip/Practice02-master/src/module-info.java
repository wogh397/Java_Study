/**
 * 
 */
/**
 * 
 */
module Practice02 {
}