package com.javaex.ex14;

public class Triangle {

	private int width;
	private int height;
	private String fillColor;
	private String lineColor;
	
}
