package com.javaex.ex07;

public class MathApp {

	public static void main(String[] args) {
		
		Math math = new Math();
		System.out.println(math.plus(5.2, 4));
		System.out.println(math.plus(4, 4));
		System.out.println(math.plus(3.2, 5.4));
		System.out.println(math.plus(100, 1.222));

	}

}
