package com.javaex.ex02;

//클래스명
public class Goods {

	//필드
	String name;
	int price;
	
	//생성자
	
	//메소드
}
