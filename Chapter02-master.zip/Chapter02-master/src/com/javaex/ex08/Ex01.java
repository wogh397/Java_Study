package com.javaex.ex08;

public class Ex01 {

	public static void main(String[] args) {
		//배열복습
			
		int[] intArray = new int[2];
		intArray[0] = 3;
		intArray[1] = 6;
		
		for(int i=0; i<intArray.length; i++) {
			System.out.println(intArray[i]);
		}
	}

}
