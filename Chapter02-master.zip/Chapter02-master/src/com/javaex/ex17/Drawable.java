package com.javaex.ex17;

public interface Drawable {

	public void draw();
	
}
